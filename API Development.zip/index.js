var express = require('express') //import / load package 
var mysql = require('mysql')

var app = express() //create an object


var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    database:'quiz'
});

//app.get('',()=>{})
/*
API Method

get
post
put
delete

*/

app.get('',(req,res)=>{ //''  default 

        res.json({msg:'test api'})
})


app.get('/get-product',(req,res)=>{

    //res.json({id:11,name:'nitin',age:23,gender:'male'})

    con.connect((err)=>{
        if(err)
        throw err 

        con.query("select * from category",(err,result,fields)=>{

            if(err)
            throw err 

            res.json({result})
        })
    })
})


app.get('/save-product',(req,res)=>{

    con.connect((err)=>{
            if(err)
                throw err 

            var sql ="insert into category(cat_name,status,created_date) values('Test11',1,'2020-08-17')";

            con.query(sql,(err,result)=>{
                    if(err)
                        throw err 
                    
                    //console.log('1 row inserted')
                    res.json({msg:'1 row inserted'})

            })
    })
  
})

app.listen(3004,()=>{

    console.log('project is running at 3010')
})

